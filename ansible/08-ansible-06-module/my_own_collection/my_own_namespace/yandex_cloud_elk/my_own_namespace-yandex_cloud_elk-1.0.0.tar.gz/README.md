# Ansible Collection - my_own_namespace.yandex_cloud_elk

This is ansible collectiont for testing my own module. 
It writes out content from variable "content" to file by the path and name from variable "path".
This collection, and role writes only for testing new simple module for ansible.
